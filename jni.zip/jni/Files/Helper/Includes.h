#include <jni.h>
#include <errno.h>

#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <vector>
#include <map>
#include <iomanip>
#include <thread>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <sys/uio.h>
#include <vector>
#include <string>
#include <chrono>
#include <algorithm>

#include <fcntl.h>
#include <android/log.h>
#include <pthread.h>
#include <dirent.h>
#include <list>
#include <libgen.h>

#include <sys/mman.h>
#include <sys/wait.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>

#include <codecvt>
#include <chrono>
#include <queue>

using namespace std::chrono_literals;

#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include <sys/system_properties.h>
#include <Files/Helper/android_native_app_glue.h>

#define LOG_TAG "Log Test dbrr"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

#define HOOK(target, hook, original) Tools::Hook((void *)(target), (void *)(hook), (void **)(original))
// Hook / Imgui
#include "../imgui/imgui.h"
#include "../imgui/backends/imgui_impl_android.h"
#include "../imgui/backends/imgui_impl_opengl3.h"
//--------------------------- Files/Helper
#include "XorStr.h"
#include "obfuscate.h"
#include "json.hpp"
#include "StrEnc.h"
#include "Mau.h"
#include "Vector3.hpp"
#include "Vector2.hpp"
#include "Tools.h"
#include "Log.h"
#include "../FTools/ImguiPP.h"
#include "font_awesome_6.h"
#include "../FTools/Font.h"
#include "../FTools/Icon.h"
#include "../FTools/FontPC.h"
#include "../imgui/imgui_internal.h"
#include "imgui_notify.h"
#include "fake_dlfcn.h"
#include <math.h>
// Other Nigga
#include "../SDK.hpp"
#include "Files/Oxorany/oxorany.h"
#include "../Hook/Utils.h"
#include "../KittyMemory/MemoryPatch.h"
#include "../Hook/Utils.h"
#include "../Hook/Macros.h"
#include "../Hook/Logger.h"
#include <string.h>
#include "Files/GlossHook/include/Gloss.h"//shadowhook渲染
#include <vector>
#include <random>
#include <iostream>
#include <cstdio>

using namespace std;
#include "../../Main/Offset.h"
#include "../../Main/ESP/Config.h"
#include "../../Main/ESP/Setting.h"
#include "Files/Helper/skCrypter.h"
#include "User.h"
#include "goku.h"
#include <cstring>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include "../../KeyAuth.hpp"
#include "../../Main/ESP/virtual_keyboard.h"
#include "LoginAuth.h"
namespace settings {

    inline ImVec4 particleColour = ImVec4(255, 255, 255, 255);

}

ImFont *pRegularFont;
ImFont *Icon;

struct TeamColor {
    uint8_t r;
    uint8_t g;
    uint8_t b;
};

ImU32 Black1 = IM_COL32(0, 0, 0, 150);
ImU32 Black = IM_COL32(0, 0, 0, 255);
ImU32 Green = IM_COL32(0, 255, 0, 255);
ImU32 Yellow = IM_COL32(255, 255, 0, 255);
ImU32 Red = IM_COL32(255, 0, 0, 255);
ImU32 Red2 = IM_COL32(255, 0, 0, 255);
ImU32 White = IM_COL32(255, 255, 255, 255);

struct VECTOR3
{
    float X;
    float Y;
    float Z;
};
ImDrawList* pImGuiDraw;

void DrawBorderString(ImFont *pFont, float FontSize, string Text, float X, float Y, ImColor Color, bool Center)
{
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    if (Setting::textborder)
    {
        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y + 1.0f), Black1, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y - 1.0f), Black1, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y - 1.0f), Black1, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y + 1.0f), Black1, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Text.c_str());
    }
    else
    {

        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Text.c_str());
    }
}
void DrawBorderStringW(ImFont *pFont, float FontSize, wstring Text, float X, float Y, ImColor Color, ImColor Color2, bool Center)
{
pImGuiDraw = ImGui::GetBackgroundDrawList();
    std::wstring_convert<std::codecvt_utf8<wchar_t>> myconv;
    std::string Texts = myconv.to_bytes(Text).c_str();
    if (Setting::textborder)
    {
        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y + 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y - 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y - 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y + 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Texts.c_str());
    }
    else
    {
        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Texts.c_str());
    }
}

void DrawFilledRectangle(float X, float Y, float Width, float Height, ImColor Color) {
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    pImGuiDraw->AddRectFilled(ImVec2(X, Y), ImVec2(X - Width, Y - Height), Color);
}
      
void test_DrawLine(ImDrawList* pImGuiDraw, float X1, float Y1, float X2, float Y2, ImColor Color, float Thickness)
{
  pImGuiDraw->AddLine(ImVec2(X1, Y1), ImVec2(X2, Y2), Color, Thickness);
}

void CornerBox(ImDrawList* pImGuiDraw, int x, int y, int w, int h, int thickness, float cornered, ImColor color)
{
  test_DrawLine(pImGuiDraw, x, y, x + (w * cornered), y, color, thickness);
  test_DrawLine(pImGuiDraw, x, y, x, y + (h * cornered), color, thickness);
  // Left Bottom
  test_DrawLine(pImGuiDraw, x, y + h, x + (w * cornered), y + h, color, thickness);
  test_DrawLine(pImGuiDraw, x, y + h, x, (y + h) - (h * cornered), color, thickness);
  // Right Top
  test_DrawLine(pImGuiDraw, x + w, y, (x + w) - (w * cornered), y, color, thickness);
  test_DrawLine(pImGuiDraw, x + w, y, x + w, y + (h * cornered), color, thickness);
  // Right Bottom
  test_DrawLine(pImGuiDraw, x + w, y + h, (x + w) - (w * cornered), y + h, color, thickness);
  test_DrawLine(pImGuiDraw, x + w, y + h, x + w, (y + h) - (h * cornered), color, thickness);
}
bool fileExists(const std::string &filePath)
{

    std::ifstream file(filePath);

    return file.good();
}

void rect_filled(float X, float Y, float Width, float Height, ImColor Color) {
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    pImGuiDraw->AddRectFilled(ImVec2(X, Y), ImVec2(X - Width, Y - Height), Color);
  }

void rect_filled_2(float X, float Y, float Width, float Height, ImColor Color) {
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    pImGuiDraw->AddRectFilled(ImVec2(X, Y), ImVec2(X + Width, Y + Height), Color);
}
// ======================================================================== //

#define IM_CLAMP(V, MN, MX) ((V) < (MN) ? (MN) : (V) > (MX) ? (MX) \
                                                            : (V))
namespace Settings
{
    static int Tab = 1;
    //Funcation Fake
    
}
static bool VR = false;
void Theme()
{
        
        ImGuiStyle& style = ImGui::GetStyle();
        
        style.WindowPadding = ImVec2(8, 8);
        style.WindowRounding = 3.5f;
        style.FramePadding = ImVec2(4, 4);
        style.ScrollbarSize = 0.0f;
        style.FrameRounding = 3.5f;
        style.FrameBorderSize = 0.0f;
        style.WindowBorderSize = 0.0f;
        style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
        style.GrabMinSize = 20.f;
           
        
        style.WindowTitleAlign = ImVec2(0.5, 0.5);
        style.ButtonTextAlign = ImVec2(0.5,0.5);
        
    style.Colors[ImGuiCol_Text] = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.3733868300914764f, 0.3733879625797272f, 0.3733905553817749f, 1.0f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.0784313753247261f, 0.08627451211214066f, 0.1019607856869698f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.0784313753247261f, 0.08627451211214066f, 0.1019607856869698f, 1.0f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.0784313753247261f, 0.08627451211214066f, 0.1019607856869698f, 1.0f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.1568627506494522f, 0.168627455830574f, 0.1921568661928177f, 1.0f);
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.0784313753247261f, 0.08627451211214066f, 0.1019607856869698f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.1568627506494522f, 0.168627455830574f, 0.1921568661928177f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.3819709122180939f, 0.3819704055786133f, 0.3819742202758789f, 1.0f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.0784313753247261f, 0.08627451211214066f, 0.1019607856869698f, 1.0f);
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.09803921729326248f, 0.105882354080677f, 0.1215686276555061f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.1568627506494522f, 0.168627455830574f, 0.1921568661928177f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.5836910009384155f, 0.8123930692672729f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.252629429101944f, 0.2689886689186096f, 0.278969943523407f, 1.0f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.5193081498146057f, 0.5193088054656982f, 0.5193133354187012f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.2789671421051025f, 0.278969943523407f, 0.2789685428142548f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.3004265427589417f, 0.3004261553287506f, 0.3004291653633118f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.557934582233429f, 0.5579342842102051f, 0.557939887046814f, 1.0f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.6137280464172363f, 0.6137277483940125f, 0.6137338876724243f, 1.0f);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.1568627506494522f, 0.1843137294054031f, 0.250980406999588f, 1.0f);
    style.Colors[ImGuiCol_SeparatorHovered] = ImVec4(0.1568627506494522f, 0.1843137294054031f, 0.250980406999588f, 1.0f);
    style.Colors[ImGuiCol_SeparatorActive] = ImVec4(0.1568627506494522f, 0.1843137294054031f, 0.250980406999588f, 1.0f);
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.5364755988121033f, 0.5364753007888794f, 0.5364806652069092f, 1.0f);
    style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.5622264742851257f, 0.5622261762619019f, 0.5622317790985107f, 1.0f);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_TabHovered] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_TabActive] = ImVec4(0.09803921729326248f, 0.105882354080677f, 0.1215686276555061f, 1.0f);
    style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.0784313753247261f, 0.08627451211214066f, 0.1019607856869698f, 1.0f);
    style.Colors[ImGuiCol_PlotLines] = ImVec4(0.5215686559677124f, 0.6000000238418579f, 0.7019608020782471f, 1.0f);
    style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.03921568766236305f, 0.9803921580314636f, 0.9803921580314636f, 1.0f);
    style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.9999930858612061f, 0.9999899864196777f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.8326179981231689f, 0.8326096534729004f, 0.8326135873794556f, 1.0f);
    style.Colors[ImGuiCol_TableHeaderBg] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_TableBorderStrong] = ImVec4(0.0470588244497776f, 0.05490196123719215f, 0.07058823853731155f, 1.0f);
    style.Colors[ImGuiCol_TableBorderLight] = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    style.Colors[ImGuiCol_TableRowBg] = ImVec4(0.1176470592617989f, 0.1333333402872086f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_TableRowBgAlt] = ImVec4(0.09803921729326248f, 0.105882354080677f, 0.1215686276555061f, 1.0f);
    style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.5879772901535034f, 0.5879769325256348f, 0.5879828333854675f, 1.0f);
    style.Colors[ImGuiCol_DragDropTarget] = ImVec4(0.9999899864196777f, 0.9999902844429016f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.9999899864196777f, 0.9999902844429016f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(0.9999899864196777f, 0.9999903440475464f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(9.999915846492513e-07f, 9.999899930335232e-07f, 9.999999974752427e-07f, 0.501960813999176f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(9.999905614677118e-07f, 9.999899930335232e-07f, 9.999999974752427e-07f, 0.501960813999176f);
    }
#define STB_IMAGE_IMPLEMENTATION
#include "../imgui/stb_image.h"



void AddUnderLine(ImColor col_)
{
    ImVec2 min = ImGui::GetItemRectMin();
    ImVec2 max = ImGui::GetItemRectMax();
    min.y = max.y;
    ImGui::GetWindowDrawList()->AddLine(min, max, col_, 1.0f);
}
void TextURL(const char *name_, const char *URL_, uint8_t SameLineBefore_, uint8_t SameLineAfter_)
{
    if (1 == SameLineBefore_)
    {
        ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
    }
    
    ImGui::PushStyleColor(ImGuiCol_Text, {255, 255, 255, 255});
    ImGui::Text(name_);
    ImGui::PopStyleColor();
    
    if (ImGui::IsItemHovered())
    {
        if (ImGui::IsMouseClicked(0))
        {
            OpenURL(URL_);
        }
        AddUnderLine({255, 193, 000, 255});
     //   ImGui::SetTooltip(ICON_FA_LINK "  Open in browser\n%s", URL_);
    }
    else
    {
        AddUnderLine({255, 255, 255, 255});
    }
    if (1 == SameLineAfter_)
    {
        ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
    }
}
void linevertical()
    {
        ImGui::SameLine();
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
        ImGui::SameLine();
}
