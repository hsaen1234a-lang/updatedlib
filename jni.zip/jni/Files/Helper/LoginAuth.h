
std::string name = XorStr("omar");// application name. right above the blurred text aka the secret on the licenses tab among other tabs
std::string ownerid = XorStr("hcNrqxdmcy"); // ownerid, found in account settings. click your profile picture on top right of dashboard and then account settings.
std::string secret = XorStr("503033362e0c455cbe267c9962ca747c30ba50573d0c7b0da1596f98610f1824"); // seller key, the blurred text on seller setting tab
std::string version = XorStr("1.0"); // leave alone unless you've changed version on website
std::string url = XorStr("https://keyauth.win/api/1.2/"); //licenceauth is free auth service (free seller plan), use KeyAuth if you have a seller plan
KeyAuth keyAuth(name, ownerid, version, url, secret);
void* anti_crack(void* arg) {
    KeyAuth* keyAuth = (KeyAuth*)arg;
    std::string original_url = keyAuth->getUrl();

    while (true) {
        if (keyAuth->getUrl() != original_url) {
            break;
        }

        std::string server_check = keyAuth->var(oxorany("SERVER_CHECK"));
        if (server_check != oxorany("VALID_SERVER")) {
            break;
        }

        std::string id = keyAuth->var(oxorany("AntiCoRach"));
        if (id != oxorany("99999999")) {
            break;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(30000)); // Kiểm tra mỗi 30 giây
    }
    return nullptr;
}


bool iLogin = false;
#define SLEEP_TIME 1000LL / 90LL
static bool opened = true;
static bool activehack = true;
bool ifismembotenable = false;
int selectedTab = 1;
using namespace ImGui;
std::vector<channel_struct> ChatMessages;
void Messages()
{
    while (true)
    {
        if (iLogin)
        {
            ChatMessages = keyAuth.chatget("Test"); //chat name
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}
void GetNewMessages()
{
    std::string lastMessage;
    while (true)
    {
       if (iLogin)
        {

            if (!ChatMessages.empty())
            {
                if (lastMessage != ChatMessages.back().author)
                {
                    lastMessage = ChatMessages.back().author;
                    std::string msgg = "New Message [" + ChatMessages.back().message + "] : \n" + ChatMessages.back().author;
                    ThanhCong(msgg.c_str(), 3000);
                }
            }
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}
void SendMessages()
{
    while (true)
    {
        if (iLogin && selectedTab == 1)
       {
        
            keyAuth.chatsend("Test", input); //chat name
            input.clear();
            std::this_thread::sleep_for(std::chrono::seconds(1));
            return;
            
        }
    }
}
bool LoginTest = false;

bool showCircle = false;
#include <thread>
#include <chrono>

void CheckKey()
{
    if (!isrequestcompleted)
    {
        return;
    }

    showCircle = true;
    isrequestcompleted = false;
    LoginTest = true;
    authtextcolor = {1.00f, 1.00f, 0.00f, 1.00f};
    authtext = "Preparing for authentication...";

    if (!iskeyauthinited)
    {
        keyAuth.init();
        iskeyauthinited = true;

        // Run anti_crack in a detached thread, as it may be long-running
        std::thread anti_crack_thread(&KeyAuth::anti_crack, &keyAuth, nullptr);
        anti_crack_thread.detach();
    }

    int returnsvr = keyAuth.license(username);
    if (returnsvr == 0)
    {
        authtextcolor = {0.07f, 0.52f, 0.17f, 1.0f};
        authtext = "Activated successfully starting...";
        std::this_thread::sleep_for(std::chrono::seconds(1));
        showCircle = false;
        iLogin = true;
        LoginTest = false;
    }
    else if (returnsvr == 1)
    {
        authtextcolor = {1.0f, 0.0f, 0.0f, 1.0f};
        authtext = "This license has been banned.";
        LoginTest = false;
    }
    else if (returnsvr == 10)
    {
        authtextcolor = {1.0f, 0.0f, 0.0f, 1.0f};
        authtext = "Connection failed. Unable to connect to host.";
        LoginTest = false;
        isrequestcompleted = true;
    }
    else if (returnsvr == 2)
    {
        authtextcolor = {1.0f, 0.0f, 0.0f, 1.0f};
        authtext = "Device ID is not match.";
        LoginTest = false;
    }
    else if (returnsvr == 3)
    {
        authtextcolor = {1.0f, 0.0f, 0.0f, 1.0f};
        authtext = "Key not match.";
        LoginTest = false;
    }
    else if (returnsvr == 4)
    {
        authtextcolor = {1.0f, 0.0f, 0.0f, 1.0f};
        authtext = "License is expired.";
        LoginTest = false;
    }
    else
    {
        authtextcolor = {1.0f, 0.0f, 0.0f, 1.0f};
        authtext = "Invalid key.";
        LoginTest = false;
    }
    isrequestcompleted = true;
}


char buffer[256];
const char* text = "Welcome to Mod Menu Cheat, please login first...";
int length = strlen(text);
float timer = 0.0f;
int index = 0;
