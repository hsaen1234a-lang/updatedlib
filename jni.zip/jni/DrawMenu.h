#pragma once


int SlideSize = 300;

void DrawCenteredTextColored(const ImVec4& color, const char* text) {
    float text_width = ImGui::CalcTextSize(text).x;
    float window_width = ImGui::GetContentRegionAvail().x;
    ImGui::SetCursorPosX((window_width - text_width) * 0.5f);
    ImGui::TextColored(color, text);
}

void AddItem(const char *CheckboxName, bool *CheckboxbooleanPtr, float *sizefloatptr, float *colorfloatptr)
{
    ImGui::TableNextRow();
    ImGui::TableNextColumn();
    ImGui::Checkbox(CheckboxName, CheckboxbooleanPtr);

    ImGui::TableNextColumn();
    ImGui::Text(CheckboxName);

    ImGui::TableNextColumn();
    ImGui::PushItemWidth(200);
    ImGui::SliderFloat((std::string("##") + CheckboxName + "size").c_str(), sizefloatptr, 1.0f, 50.0f, "%.0f");

    ImGui::TableNextColumn();
    ImGui::ColorEdit4((std::string("##") + CheckboxName + "color").c_str(), colorfloatptr, ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoInputs);

    ImGui::Separator();
}
void DrawItemsTab() {
                        ImGui::BeginChild("#Items", ImVec2(0, 0), true, 0);
                        {
                            ImGui::Checkbox(GetLabel("Show Items", "Hiển thị vật phẩm", "显示物品"), &Setting::Item);
                            ImGui::SameLine();
                            ImGui::Checkbox(GetLabel("Show items inside loot box", "Hiển thị vật phẩm bên trong hộp loot", "显示战利品箱内的物品"), &Config.ESPMenu.LootBoxItems);
                            ImGui::SameLine();
                            ImGui::Checkbox(GetLabel("Show Nearest AR", "Hiển thị vũ khí AR gần nhất", "显示最近的步枪"), &Setting::nearstAR);
                            if(Setting::Item) {
                                       /* ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.0f);
                                        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6.0f);*/
                                        ImGui::BeginChild("VatPham#1", ImVec2(0, 0), true);
                                       // ImGui::PopStyleVar(2);
                                        {
                                            if (ImGui::BeginTabBar("Item"))
                                            {
                                                if (ImGui::BeginTabItem(GetLabel("Weapon", "Vũ Khí", "武器")))
                                                {
                                                    ImGui::BeginChild("Weap#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    ImGuiStyle &style = ImGui::GetStyle();
                                                    if (ImGui::BeginTable("###Weapon", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();

                                                        style.ScrollbarSize = 40.0f;
                                                        AddItem("M416", &Setting::Esp_Item_M416, &Setting::Esp_Item_M416_TextSize, (float *)&Setting::Esp_Item_M416_Color);
                                                        AddItem("SCAR-L", &Setting::Esp_Item_SCARL, &Setting::Esp_Item_SCARL_TextSize, (float *)&Setting::Esp_Item_SCARL_Color);
                                                        AddItem("AKM", &Setting::Esp_Item_AKM, &Setting::Esp_Item_AKM_TextSize, (float *)&Setting::Esp_Item_AKM_Color);
                                                        AddItem("AUG", &Setting::Esp_Item_AUG, &Setting::Esp_Item_AUG_TextSize, (float *)&Setting::Esp_Item_AUG_Color);
                                                        AddItem("QBZ", &Setting::Esp_Item_QBZ, &Setting::Esp_Item_QBZ_TextSize, (float *)&Setting::Esp_Item_QBZ_Color);
                                                        AddItem("M762", &Setting::Esp_Item_M762, &Setting::Esp_Item_M762_TextSize, (float *)&Setting::Esp_Item_M762_Color);
                                                        AddItem("MK-14", &Setting::Esp_Item_Mk14, &Setting::Esp_Item_Mk14_TextSize, (float *)&Setting::Esp_Item_Mk14_Color);
                                                        AddItem("Mini14", &Setting::Esp_Item_Mini14, &Setting::Esp_Item_Mini14_TextSize, (float *)&Setting::Esp_Item_Mini14_Color);
                                                        AddItem("SKS", &Setting::Esp_Item_SKS, &Setting::Esp_Item_SKS_TextSize, (float *)&Setting::Esp_Item_SKS_Color);
                                                        AddItem("SLR", &Setting::Esp_Item_SLR, &Setting::Esp_Item_SLR_TextSize, (float *)&Setting::Esp_Item_SLR_Color);
                                                        AddItem("M24", &Setting::Esp_Item_M24, &Setting::Esp_Item_M24_TextSize, (float *)&Setting::Esp_Item_M24_Color);
                                                        AddItem("Kar98k", &Setting::Esp_Item_Kar98k, &Setting::Esp_Item_Kar98k_TextSize, (float *)&Setting::Esp_Item_Kar98k_Color);
                                                        AddItem("Mosin Nagant", &Setting::Esp_Item_Mosin, &Setting::Esp_Item_Mosin_TextSize, (float *)&Setting::Esp_Item_Mosin_Color);
                                                        AddItem("AMR", &Setting::Esp_Item_Awm, &Setting::Esp_Item_Awm_TextSize, (float *)&Setting::Esp_Item_Awm_Color);
                                                        AddItem("AWM", &Setting::Esp_Item_Awm, &Setting::Esp_Item_Awm_TextSize, (float *)&Setting::Esp_Item_Awm_Color);
                                                        AddItem("M249", &Setting::Esp_Item_M249, &Setting::Esp_Item_M249_TextSize, (float *)&Setting::Esp_Item_M249_Color);
                                                        AddItem("MG3", &Setting::Esp_Item_M249, &Setting::Esp_Item_M249_TextSize, (float *)&Setting::Esp_Item_M249_Color);
                                                        AddItem("DP-28", &Setting::Esp_Item_DP28, &Setting::Esp_Item_DP28_TextSize, (float *)&Setting::Esp_Item_DP28_Color);
                                                        AddItem("Groza", &Setting::Esp_Item_Groza, &Setting::Esp_Item_Groza_TextSize, (float *)&Setting::Esp_Item_Groza_Color);
                                                        AddItem("DBS", &Setting::Esp_Item_DBS, &Setting::Esp_Item_DBS_TextSize, (float *)&Setting::Esp_Item_DBS_Color);
                                                        AddItem("MK-47 Mutant", &Setting::Esp_Item_Mk47Mutant, &Setting::Esp_Item_Mk47Mutant_TextSize, (float *)&Setting::Esp_Item_Mk47Mutant_Color);
                                                        AddItem("MK12", &Setting::Esp_Item_Mk12, &Setting::Esp_Item_Mk12_TextSize, (float *)&Setting::Esp_Item_Mk12_Color);
                                                        AddItem("Famas", &Setting::Esp_Item_Mk12, &Setting::Esp_Item_Mk12_TextSize, (float *)&Setting::Esp_Item_Mk12_Color);
                                                        AddItem("AN94", &Setting::Esp_Item_Mk12, &Setting::Esp_Item_Mk12_TextSize, (float *)&Setting::Esp_Item_Mk12_Color);
                                                        AddItem("Crossbow", &Setting::Esp_Item_CrossBow, &Setting::Esp_Item_CrossBow_TextSize, (float *)&Setting::Esp_Item_CrossBow_Color);
                                                        AddItem("QBU", &Setting::Esp_Item_QBU, &Setting::Esp_Item_QBU_TextSize, (float *)&Setting::Esp_Item_QBU_Color);
                                                        AddItem("G36C", &Setting::Esp_Item_G36C, &Setting::Esp_Item_G36C_TextSize, (float *)&Setting::Esp_Item_G36C_Color);
                                                        AddItem("M16A4", &Setting::Esp_Item_M16A4, &Setting::Esp_Item_M16A4_TextSize, (float *)&Setting::Esp_Item_M16A4_Color);
                                                        AddItem("Sawed-Off", &Setting::Esp_Item_SawedOff, &Setting::Esp_Item_SawedOff_TextSize, (float *)&Setting::Esp_Item_SawedOff_Color);
                                                        AddItem("S12K", &Setting::Esp_Item_S12K, &Setting::Esp_Item_S12K_TextSize, (float *)&Setting::Esp_Item_S12K_Color);
                                                        AddItem("S1897", &Setting::Esp_Item_S1897, &Setting::Esp_Item_S1897_TextSize, (float *)&Setting::Esp_Item_S1897_Color);
                                                        AddItem("S686", &Setting::Esp_Item_S686, &Setting::Esp_Item_S686_TextSize, (float *)&Setting::Esp_Item_S686_Color);
                                                        AddItem("M1014", &Setting::Esp_Item_M1014, &Setting::Esp_Item_M1014_TextSize, (float *)&Setting::Esp_Item_M1014_Color);
                                                        AddItem("VSS", &Setting::Esp_Item_VSS, &Setting::Esp_Item_VSS_TextSize, (float *)&Setting::Esp_Item_VSS_Color);
                                                        AddItem("UMP9", &Setting::Esp_Item_UMP9, &Setting::Esp_Item_UMP9_TextSize, (float *)&Setting::Esp_Item_UMP9_Color);
                                                        AddItem("UZI", &Setting::Esp_Item_Uzi, &Setting::Esp_Item_Uzi_TextSize, (float *)&Setting::Esp_Item_Uzi_Color);
                                                        AddItem("P18C", &Setting::Esp_Item_P18C, &Setting::Esp_Item_P18C_TextSize, (float *)&Setting::Esp_Item_P18C_Color);
                                                        AddItem("P92", &Setting::Esp_Item_P92, &Setting::Esp_Item_P92_TextSize, (float *)&Setting::Esp_Item_P92_Color);
                                                        AddItem("Win94", &Setting::Esp_Item_Win94, &Setting::Esp_Item_Win94_TextSize, (float *)&Setting::Esp_Item_Win94_Color);
                                                        AddItem("Thompson", &Setting::Esp_Item_TommyGun, &Setting::Esp_Item_TommyGun_TextSize, (float *)&Setting::Esp_Item_TommyGun_Color);
                                                        AddItem("Vector", &Setting::Esp_Item_Vector, &Setting::Esp_Item_Vector_TextSize, (float *)&Setting::Esp_Item_Vector_Color);
                                                        AddItem("R45", &Setting::Esp_Item_R45, &Setting::Esp_Item_R45_TextSize, (float *)&Setting::Esp_Item_R45_Color);
                                                        AddItem("P1911", &Setting::Esp_Item_P1911, &Setting::Esp_Item_P1911_TextSize, (float *)&Setting::Esp_Item_P1911_Color);
                                                        AddItem("Desert Eagle", &Setting::Esp_Item_DesertEagle, &Setting::Esp_Item_DesertEagle_TextSize, (float *)&Setting::Esp_Item_DesertEagle_Color);
                                                        AddItem("R1895", &Setting::Esp_Item_R1895, &Setting::Esp_Item_R1895_TextSize, (float *)&Setting::Esp_Item_R1895_Color);
                                                        AddItem("Skorpion", &Setting::Esp_Item_MP5K, &Setting::Esp_Item_MP5K_TextSize, (float *)&Setting::Esp_Item_MP5K_Color);
                                                        AddItem("MP5K", &Setting::Esp_Item_MP5K, &Setting::Esp_Item_MP5K_TextSize, (float *)&Setting::Esp_Item_MP5K_Color);
                                                        AddItem("P90", &Setting::Esp_Item_PP19, &Setting::Esp_Item_PP19_TextSize, (float *)&Setting::Esp_Item_PP19_Color);
                                                        AddItem("PP-19 Bizon", &Setting::Esp_Item_PP19, &Setting::Esp_Item_PP19_TextSize, (float *)&Setting::Esp_Item_PP19_Color);
                                                        AddItem("Panzer Faust", &Setting::Esp_Item_PP19, &Setting::Esp_Item_PP19_TextSize, (float *)&Setting::Esp_Item_PP19_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Grenade", "Lựu đạn", "手榴弹")))
                                                {
                                                    ImGui::BeginChild("Gren#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###Gre", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("Smoke Grenade", &Setting::Esp_Item_Smoke, &Setting::Esp_Item_Smoke_TextSize, (float *)&Setting::Esp_Item_Smoke_Color);
                                                        AddItem("Sticky Bomb", &Setting::Esp_Item_Frag, &Setting::Esp_Item_Frag_TextSize, (float *)&Setting::Esp_Item_Frag_Color);
                                                        AddItem("Frag Grenade", &Setting::Esp_Item_Frag, &Setting::Esp_Item_Frag_TextSize, (float *)&Setting::Esp_Item_Frag_Color);
                                                        AddItem("Molotov Cocktail", &Setting::Esp_Item_molotov, &Setting::Esp_Item_molotov_TextSize, (float *)&Setting::Esp_Item_molotov_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Health", "Cứu Thương", "医疗")))
                                                {
                                                    ImGui::BeginChild("Bitch#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###Bitch", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("Painkiller", &Setting::Esp_Item_Painkiller, &Setting::Esp_Item_Painkiller_TextSize, (float *)&Setting::Esp_Item_Painkiller_Color);
                                                        AddItem("Energy Drink", &Setting::Esp_Item_EnergyDrink, &Setting::Esp_Item_EnergyDrink_TextSize, (float *)&Setting::Esp_Item_EnergyDrink_Color);
                                                        AddItem("Adrenaline Syringe", &Setting::Esp_Item_AdrenalineSyringe, &Setting::Esp_Item_AdrenalineSyringe_TextSize, (float *)&Setting::Esp_Item_AdrenalineSyringe_Color);
                                                        AddItem("Med Kit", &Setting::Esp_Item_MedKit, &Setting::Esp_Item_MedKit_TextSize, (float *)&Setting::Esp_Item_MedKit_Color);
                                                        AddItem("First Aid Kit", &Setting::Esp_Item_FirstAidKit, &Setting::Esp_Item_FirstAidKit_TextSize, (float *)&Setting::Esp_Item_FirstAidKit_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Backpack", "Balo", "背包")))
                                                {
                                                    ImGui::BeginChild("Fuc#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###Fuuck", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("Backpack lv.3", &Setting::Esp_Item_Bag3, &Setting::Esp_Item_Bag3_TextSize, (float *)&Setting::Esp_Item_Bag3_Color);
                                                        AddItem("Backpack lv.2", &Setting::Esp_Item_Bag2, &Setting::Esp_Item_Bag2_TextSize, (float *)&Setting::Esp_Item_Bag2_Color);
                                                        AddItem("Backpack lv.1", &Setting::Esp_Item_Bag1, &Setting::Esp_Item_Bag1_TextSize, (float *)&Setting::Esp_Item_Bag1_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Helmet", "Mũ", "头盔")))
                                                {
                                                    ImGui::BeginChild("Laadll#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###BuonChan", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("Helmet lv.3", &Setting::Esp_Item_Helmet3, &Setting::Esp_Item_Helmet3_TextSize, (float *)&Setting::Esp_Item_Helmet3_Color);
                                                        AddItem("Helmet lv.2", &Setting::Esp_Item_Helmet2, &Setting::Esp_Item_Helmet2_TextSize, (float *)&Setting::Esp_Item_Helmet2_Color);
                                                        AddItem("Helmet lv.1", &Setting::Esp_Item_Helmet1, &Setting::Esp_Item_Helmet1_TextSize, (float *)&Setting::Esp_Item_Helmet1_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Armor", "Giáp", "护甲")))
                                                {
                                                    ImGui::BeginChild("Amor#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###Armor", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("Armor lv.3", &Setting::Esp_Item_Armor3, &Setting::Esp_Item_Armor3_TextSize, (float *)&Setting::Esp_Item_Armor3_Color);
                                                        AddItem("Armor lv.2", &Setting::Esp_Item_Armor2, &Setting::Esp_Item_Armor2_TextSize, (float *)&Setting::Esp_Item_Armor2_Color);
                                                        AddItem("Armor lv.1", &Setting::Esp_Item_Armor1, &Setting::Esp_Item_Armor1_TextSize, (float *)&Setting::Esp_Item_Armor1_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Ammo", "Đạn", "弹药")))
                                                {
                                                    ImGui::BeginChild("Ammo#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###Ammo", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("7.62", &Setting::Esp_Item_762mm, &Setting::Esp_Item_762mm_TextSize, (float *)&Setting::Esp_Item_762mm_Color);
                                                        AddItem("5.56", &Setting::Esp_Item_556mm, &Setting::Esp_Item_556mm_TextSize, (float *)&Setting::Esp_Item_556mm_Color);
                                                        AddItem("9mm", &Setting::Esp_Item_9mm, &Setting::Esp_Item_9mm_TextSize, (float *)&Setting::Esp_Item_9mm_Color);
                                                        AddItem(".45 ACP", &Setting::Esp_Item_45ACP, &Setting::Esp_Item_45ACP_TextSize, (float *)&Setting::Esp_Item_45ACP_Color);
                                                        AddItem("12 Guage", &Setting::Esp_Item_12Guage, &Setting::Esp_Item_12Guage_TextSize, (float *)&Setting::Esp_Item_12Guage_Color);
                                                        AddItem(".300 Magnum", &Setting::Esp_Item_Magnum, &Setting::Esp_Item_Magnum_TextSize, (float *)&Setting::Esp_Item_Magnum_Color);
                                                        AddItem(".50 ACP", &Setting::Esp_Item_Magnum, &Setting::Esp_Item_Magnum_TextSize, (float *)&Setting::Esp_Item_Magnum_Color);
                                                        AddItem("Bolt", &Setting::Esp_Item_Magnum, &Setting::Esp_Item_Magnum_TextSize, (float *)&Setting::Esp_Item_Magnum_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Attachments", "Phụ Kiện", "附件")))
                                                {
                                                    ImGui::BeginChild("Attchment#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    ImGuiStyle &style = ImGui::GetStyle();
                                                    style.ScrollbarSize = 40.0f;
                                                    if (ImGui::BeginTable("###Attachments", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("8x scope", &Setting::Esp_Item_x8, &Setting::Esp_Item_x8_TextSize, (float *)&Setting::Esp_Item_x8_Color);
                                                        AddItem("6x scope", &Setting::Esp_Item_x6, &Setting::Esp_Item_x6_TextSize, (float *)&Setting::Esp_Item_x6_Color);
                                                        AddItem("4x scope", &Setting::Esp_Item_x4, &Setting::Esp_Item_x4_TextSize, (float *)&Setting::Esp_Item_x4_Color);
                                                        AddItem("3x scope", &Setting::Esp_Item_x3, &Setting::Esp_Item_x3_TextSize, (float *)&Setting::Esp_Item_x3_Color);
                                                        AddItem("2x Scope", &Setting::Esp_Item_x2, &Setting::Esp_Item_x2_TextSize, (float *)&Setting::Esp_Item_x2_Color);
                                                        AddItem("Holo", &Setting::Esp_Item_Holo, &Setting::Esp_Item_Holo_TextSize, (float *)&Setting::Esp_Item_Holo_Color);
                                                        AddItem("Red dot", &Setting::Esp_Item_RedDot, &Setting::Esp_Item_RedDot_TextSize, (float *)&Setting::Esp_Item_RedDot_Color);
                                                        AddItem("Canted Sight", &Setting::Esp_Item_BP_WB_Lasersight_Pickup_C, &Setting::Esp_Item_BP_WB_Lasersight_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_WB_Lasersight_Pickup_C_Color);
                                                        AddItem("Compensator (AR)", &Setting::Esp_Item_BP_QK_Large_Compensator_Pickup_C, &Setting::Esp_Item_BP_QK_Large_Compensator_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Large_Compensator_Pickup_C_Color);
                                                        AddItem("Suppressor (AR)", &Setting::Esp_Item_BP_QK_Large_Suppressor_Pickup_C, &Setting::Esp_Item_BP_QK_Large_Suppressor_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Large_Suppressor_Pickup_C_Color);
                                                        AddItem("Compensator (Snipers)", &Setting::Esp_Item_BP_QK_Sniper_Compensator_Pickup_C, &Setting::Esp_Item_BP_QK_Sniper_Compensator_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Sniper_Compensator_Pickup_C_Color);
                                                        AddItem("Flash Hider (Snipers)", &Setting::Esp_Item_BP_QK_Sniper_FlashHider_Pickup_C, &Setting::Esp_Item_BP_QK_Sniper_FlashHider_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Sniper_FlashHider_Pickup_C_Color);
                                                        AddItem("Suppressor (Snipers)", &Setting::Esp_Item_BP_QK_Sniper_Suppressor_Pickup_C, &Setting::Esp_Item_BP_QK_Sniper_Suppressor_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Sniper_Suppressor_Pickup_C_Color);
                                                        AddItem("Vertical foregrip", &Setting::Esp_Item_BP_WB_Vertical_Pickup_C, &Setting::Esp_Item_BP_WB_Vertical_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_WB_Vertical_Pickup_C_Color);
                                                        AddItem("Light grip", &Setting::Esp_Item_BP_WB_LightGrip_Pickup_C, &Setting::Esp_Item_BP_WB_LightGrip_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_WB_LightGrip_Pickup_C_Color);
                                                        AddItem("Half grip", &Setting::Esp_Item_BP_WB_HalfGrip_Pickup_C, &Setting::Esp_Item_BP_WB_HalfGrip_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_WB_HalfGrip_Pickup_C_Color);
                                                        AddItem("Thumb grip", &Setting::Esp_Item_BP_WB_ThumbGrip_Pickup_C, &Setting::Esp_Item_BP_WB_ThumbGrip_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_WB_ThumbGrip_Pickup_C_Color);
                                                        AddItem("Extended Quickdraw Mag (Snipers)", &Setting::Esp_Item_BP_DJ_Sniper_EQ_Pickup_C, &Setting::Esp_Item_BP_DJ_Sniper_EQ_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_DJ_Sniper_EQ_Pickup_C_Color);
                                                        AddItem("Tack stock for M416, Vector", &Setting::Esp_Item_BP_QT_UZI_Pickup_C, &Setting::Esp_Item_BP_QT_UZI_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QT_UZI_Pickup_C_Color);
                                                        AddItem("Bullet loops (Kar98, Win94)", &Setting::Esp_Item_BP_QT_UZI_Pickup_C, &Setting::Esp_Item_BP_QT_UZI_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QT_UZI_Pickup_C_Color);
                                                        AddItem("Cheek pad (Snipers)", &Setting::Esp_Item_BP_QT_Sniper_Pickup_C, &Setting::Esp_Item_BP_QT_Sniper_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QT_Sniper_Pickup_C_Color);
                                                        AddItem("Extended Quickdraw Mag (AR)", &Setting::Esp_Item_BP_DJ_Large_Q_Pickup_C, &Setting::Esp_Item_BP_DJ_Large_Q_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_DJ_Large_Q_Pickup_C_Color);
                                                        AddItem("Extended Quickdraw Mag (SMG, Pistols)", &Setting::Esp_Item_BP_DJ_Large_E_Pickup_C, &Setting::Esp_Item_BP_DJ_Large_E_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_DJ_Large_E_Pickup_C_Color);
                                                        AddItem("Quickdraw Mag (SMG, Pistols)", &Setting::Esp_Item_BP_DJ_Mid_Q_Pickup_C, &Setting::Esp_Item_BP_DJ_Mid_Q_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_DJ_Mid_Q_Pickup_C_Color);
                                                        AddItem("Extended Mag (SMG, Pistols)", &Setting::Esp_Item_BP_DJ_Mid_E_Pickup_C, &Setting::Esp_Item_BP_DJ_Mid_E_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_DJ_Mid_E_Pickup_C_Color);
                                                        AddItem("Suppressor (SMG, Pistols)", &Setting::Esp_Item_BP_QK_Mid_Suppressor_Pickup_C, &Setting::Esp_Item_BP_QK_Mid_Suppressor_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Mid_Suppressor_Pickup_C_Color);
                                                        AddItem("Compensator (SMG)", &Setting::Esp_Item_BP_QK_Mid_Compensator_Pickup_C, &Setting::Esp_Item_BP_QK_Mid_Compensator_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Mid_Compensator_Pickup_C_Color);
                                                        AddItem("Flash Hider (SMG)", &Setting::Esp_Item_BP_QK_Mid_FlashHider_Pickup_C, &Setting::Esp_Item_BP_QK_Mid_FlashHider_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_QK_Mid_FlashHider_Pickup_C_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }
                                                if (ImGui::BeginTabItem(GetLabel("Other", "Khác", "其他")))
                                                {
                                                    ImGui::BeginChild("Lồnmrj#1", ImVec2(0, 0), true);
                                                    ImGui::SetCursorPos(ImVec2(8, 8));
                                                    if (ImGui::BeginTable("###Lon", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
                                                    {
                                                        ImGui::TableSetupColumn("Show", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("TextSize", ImGuiTableColumnFlags_WidthFixed, 200.0f);
                                                        ImGui::TableSetupColumn("Color", ImGuiTableColumnFlags_WidthFixed, 24.0f);
                                                        ImGui::TableHeadersRow();
                                                        ImGui::TableNextRow();
                                                        AddItem("Pan", &Setting::Esp_Item_BP_WEP_Pan_Pickup_C, &Setting::Esp_Item_BP_WEP_Pan_Pickup_C_TextSize, (float *)&Setting::Esp_Item_BP_WEP_Pan_Pickup_C_Color);
                                                        AddItem("Flare gun", &Setting::Esp_Item_FlareGun, &Setting::Esp_Item_FlareGun_TextSize, (float *)&Setting::Esp_Item_FlareGun_Color);
                                                        AddItem("Flare", &Setting::Esp_Item_Flare, &Setting::Esp_Item_Flare_TextSize, (float *)&Setting::Esp_Item_Flare_Color);
                                                        AddItem("Golden Token", &Setting::Esp_Item_DeadBox, &Setting::Esp_Item_DeadBox_TextSize, (float *)&Setting::Esp_Item_DeadBox_Color);
                                                        AddItem("Air drop", &Setting::Esp_Item_AirDrop, &Setting::Esp_Item_AirDrop_TextSize, (float *)&Setting::Esp_Item_AirDrop_Color);
                                                        AddItem("Gas can", &Setting::Esp_Item_GasCan, &Setting::Esp_Item_GasCan_TextSize, (float *)&Setting::Esp_Item_GasCan_Color);
                                                        AddItem("Treasure Box", &Setting::Esp_Item_Event, &Setting::Esp_Item_Event_TextSize, (float *)&Setting::Esp_Item_Event_Color);
                                                        ImGui::EndTable();
                                                    }
                                                    ImGui::EndChild();
                                                    ImGui::EndTabItem();
                                                }

                                            ImGui::EndTabBar();
                                        }
                                        ImGui::EndChild();
                            }
                    }
    }
    ImGui::EndChild();
}
