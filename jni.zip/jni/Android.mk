LOCAL_PATH := $(call my-dir)
MAIN_LOCAL_PATH := $(call my-dir)


# ======================================
# Lua 5.3 Static Library
# ======================================
include $(CLEAR_VARS)
LOCAL_MODULE := lua53
LOCAL_SRC_FILES := \
    Lua/lapi.c \
    Lua/lauxlib.c \
    Lua/lbaselib.c \
    Lua/lbitlib.c \
    Lua/lcode.c \
    Lua/lcorolib.c \
    Lua/lctype.c \
    Lua/ldblib.c \
    Lua/ldebug.c \
    Lua/ldo.c \
    Lua/ldump.c \
    Lua/lfunc.c \
    Lua/lgc.c \
    Lua/linit.c \
    Lua/liolib.c \
    Lua/lmathlib.c \
    Lua/lmem.c \
    Lua/loadlib.c \
    Lua/lobject.c \
    Lua/lopcodes.c \
    Lua/loslib.c \
    Lua/lparser.c \
    Lua/lstate.c \
    Lua/lstring.c \
    Lua/lstrlib.c \
    Lua/ltable.c \
    Lua/ltablib.c \
    Lua/ltm.c \
    Lua/lundump.c \
    Lua/lutf8lib.c \
    Lua/lvm.c \
    Lua/llex.c \
    Lua/lzio.c
LOCAL_C_INCLUDES := $(LOCAL_PATH)/Lua
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/Lua
LOCAL_CFLAGS := -DLUA_USE_LINUX -DLUA_COMPAT_5_2 -fvisibility=hidden
include $(BUILD_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := GlossHook
LOCAL_SRC_FILES := Files/GlossHook/lib/$(TARGET_ARCH_ABI)/libGlossHook.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)Files/GlossHook/include/
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libcurl
LOCAL_SRC_FILES := Files/curl/curl-android-$(TARGET_ARCH_ABI)/lib/libcurl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libssl
LOCAL_SRC_FILES := Files/curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libssl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE            := libdobby
LOCAL_SRC_FILES         := Files/Dobby/libraries/$(TARGET_ARCH_ABI)/libdobby.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/dobby/
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libcrypto
LOCAL_SRC_FILES := Files/curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libcrypto.a
include $(PREBUILT_STATIC_LIBRARY)


include $(CLEAR_VARS)

LOCAL_MODULE:= a

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -Werror -s -std=c++17 -Wall
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all, -llog
LOCAL_CFLAGS += -fPIC -DPIC
LOCAL_CFLAGS += "-DDARWIN_NO_CARBON"
LOCAL_CFLAGS += "-DFT2_BUILD_LIBRARY"
LOCAL_ARM_MODE := arm
LOCAL_C_INCLUDES += $(MAIN_LOCAL_PATH)
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Lua
LOCAL_SRC_FILES :=  Main.cpp \
        Files/Oxorany/oxorany.cpp \
        Files/Helper/Tools.cpp \
                LuaInjector.cpp \
        Files/Substrate/hde64.c \
        Files/Substrate/SubstrateHook.cpp \
        Files/Substrate/SubstrateDebug.cpp \
        Files/Substrate/SubstratePosixMemory.cpp \
        Files/Substrate/And64InlineHook.cpp \
        Files/Helper/android_native_app_glue.c \
        Files/Helper/fake_dlfcn.cpp \
        Files/ImGui/ImGui.cpp    \
        Files/ImGui/ImGui_draw.cpp\
        Files/ImGui/ImGui_tables.cpp \
        Files/ImGui/ImGui_widgets.cpp \
        Files/ImGui/backends/imgui_impl_android.cpp \
        Files/ImGui/backends/imgui_impl_opengl3.cpp \
        Files/KittyMemory/KittyMemory.cpp \
        Files/KittyMemory/MemoryPatch.cpp \
        Files/KittyMemory/MemoryBackup.cpp \
        Files/KittyMemory/KittyUtils.cpp \
        Files/SDK/PUBGM_Basic.cpp \
        Files/SDK/PUBGM_Basic_functions.cpp  \
        Files/SDK/PUBGM_Engine_functions.cpp  \
        Files/SDK/PUBGM_Client_functions.cpp   \
        Files/SDK/PUBGM_CoreUObject_functions.cpp \
        Files/SDK/PUBGM_Gameplay_functions.cpp \
        Files/SDK/PUBGM_ShadowTrackerExtra_functions.cpp \
        Files/SDK/PUBGM_UMG_functions.cpp
        
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Files/curl/curl-android-$(TARGET_ARCH_ABI)/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Files/curl/openssl-android-$(TARGET_ARCH_ABI)/include

LOCAL_CPP_FEATURES := exceptions
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2 -lGLESv3 -lGLESv1_CM -lz

LOCAL_STATIC_LIBRARIES := libcurl libssl libcrypto libdobby GlossHook
include $(BUILD_SHARED_LIBRARY)

